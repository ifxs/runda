function done(id){
	alert("asdfds");
	if(confirm("是否确认收货?")){
		$.ajax({
			url: "index.php?controller=Order&method=done&orderid="+id,
			type: "GET",
			dataType:"json",
			success: function(result,textStatus){
				if(textStatus == "success"){
					alert(result.message);
					if(result.code == 200){
						setTimeout(function() {
							window.location.href="index.php?controller=Order&method=doComment&orderid="+id";
							}, 1000);
					}else{
						alert(result.message);
					}
				}else{
						alert("服务器错误");
				}
	  		},
	  		error: function (XMLHttpRequest, textStatus, errorThrown) { 
	            alert("服务器错误1 请重试"); 
	        }
		});
	}
}