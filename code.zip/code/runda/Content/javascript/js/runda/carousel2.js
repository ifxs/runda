// 调整图片轮播速度
$('.carousel').carousel({
  interval: 2000
});