<?php

//发送邮件配置
define("Transport","smtp.sina.com");
define("UserUame","xiaopxp@sina.com");
define("Password","GZ*xiaosong79");
define("Name","runda.com");