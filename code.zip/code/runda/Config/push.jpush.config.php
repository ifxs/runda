<?php
//极光推送的配置文件
define("APPKEY","9b89bd0e39491ffb67ab59c3");
define("MASTERSECRET","dd558bb5727b9d76e1f80c08");